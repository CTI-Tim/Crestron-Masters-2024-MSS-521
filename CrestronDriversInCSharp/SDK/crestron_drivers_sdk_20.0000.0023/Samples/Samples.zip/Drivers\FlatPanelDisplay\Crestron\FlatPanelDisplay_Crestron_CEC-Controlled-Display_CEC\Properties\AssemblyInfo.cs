using System.Reflection;

[assembly: AssemblyTitle("FlatPanelDisplay_Crestron_CEC-Controlled-Display_CEC")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("FlatPanelDisplay_Crestron_CEC-Controlled-Display_CEC")]
[assembly: AssemblyCopyright("Copyright © Crestron Electronics 2021")]
[assembly: AssemblyVersion("20.0000.0023")]

