using System.Reflection;

[assembly: AssemblyTitle("AVSwitcher_Crestron_SampleDriver_IP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AVSwitcher_Crestron_SampleDriver_IP")]
[assembly: AssemblyCopyright("Copyright � Crestron Electronics 2019")]
[assembly: AssemblyVersion("20.0000.0023")]

