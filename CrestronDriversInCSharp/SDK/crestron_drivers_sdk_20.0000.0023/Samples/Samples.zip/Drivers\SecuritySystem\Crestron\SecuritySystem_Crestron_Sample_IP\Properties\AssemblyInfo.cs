using System.Reflection;

[assembly: AssemblyTitle("SecuritySystem_Crestron_Sample")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SecuritySystem_Crestron_Sample")]
[assembly: AssemblyCopyright("Copyright �  2020")]
[assembly: AssemblyVersion("20.0000.0023")]

