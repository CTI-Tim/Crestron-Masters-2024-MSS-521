using System.Reflection;

[assembly: AssemblyTitle("AvReceiver_Marantz_AV8805-MultiZone_IP")]
[assembly: AssemblyCompany("Crestron Electronics")]
[assembly: AssemblyProduct("AvReceiver_Marantz_AV8805-MultiZone_IP")]
[assembly: AssemblyCopyright("Copyright � 2020")]
[assembly: AssemblyVersion("20.0000.0023")]

