using System.Reflection;

[assembly: AssemblyTitle("SecuritySystem_Crestron_SampleDriverModel_Serial")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SecuritySystem_Crestron_SampleDriverModel_Serial")]
[assembly: AssemblyCopyright("Copyright �  2020")]
[assembly: AssemblyVersion("20.0000.0023")]

