using System.Reflection;

[assembly: AssemblyTitle("BlurayPlayer_Arcam_CDS50_IP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BlurayPlayer_Arcam_CDS50_IP")]
[assembly: AssemblyCopyright("Copyright �  2019")]
[assembly: AssemblyVersion("20.0000.0023")]

