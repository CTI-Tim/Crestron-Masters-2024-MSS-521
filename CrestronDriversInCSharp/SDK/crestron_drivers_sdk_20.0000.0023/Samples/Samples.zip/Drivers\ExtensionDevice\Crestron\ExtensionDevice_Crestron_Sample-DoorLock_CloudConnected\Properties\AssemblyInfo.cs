using System.Reflection;

[assembly: AssemblyTitle("ExtensionDevice_Crestron_Sample_DoorLock_CloudConnected")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ExtensionDevice_Crestron_Sample_DoorLock_CloudConnected")]
[assembly: AssemblyCopyright("Copyright �  2020")]
[assembly: AssemblyVersion("20.0000.0023")]

