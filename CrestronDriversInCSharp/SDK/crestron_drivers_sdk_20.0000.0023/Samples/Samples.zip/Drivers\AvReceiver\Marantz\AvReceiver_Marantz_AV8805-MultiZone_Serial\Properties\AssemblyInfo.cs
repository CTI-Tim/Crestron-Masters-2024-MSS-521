using System.Reflection;

[assembly: AssemblyTitle("AvReceiver_Marantz_8805_MultiZone_Serial")]
[assembly: AssemblyCompany("Crestron Electronics")]
[assembly: AssemblyProduct("AvReceiver_Marantz_8805_MultiZone_Serial")]
[assembly: AssemblyCopyright("Copyright � 2020")]
[assembly: AssemblyVersion("20.0000.0023")]

