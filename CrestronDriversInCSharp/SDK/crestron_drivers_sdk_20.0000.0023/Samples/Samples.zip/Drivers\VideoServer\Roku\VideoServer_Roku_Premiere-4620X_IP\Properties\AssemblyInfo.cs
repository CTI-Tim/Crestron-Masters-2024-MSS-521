using System.Reflection;

[assembly: AssemblyTitle("VideoServer_Roku_Premiere_4620x_IP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("VideoServer_Roku_Premiere_4620x_IP")]
[assembly: AssemblyCopyright("Copyright �  2018")]
[assembly: AssemblyVersion("20.0000.0023")]

