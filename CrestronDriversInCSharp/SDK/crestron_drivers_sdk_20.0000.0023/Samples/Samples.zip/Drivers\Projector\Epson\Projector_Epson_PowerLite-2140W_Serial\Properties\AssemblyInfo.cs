// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="">
//   
// </copyright>
// --------------------------------------------------------------------------------------------------------------------



using System.Reflection;

[assembly: AssemblyTitle("Projector_Epson_PowerLite-2140W_Serial")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("Projector_Epson_PowerLite-2140W_Serial")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2017")]
[assembly: AssemblyVersion("20.0000.0023")]

