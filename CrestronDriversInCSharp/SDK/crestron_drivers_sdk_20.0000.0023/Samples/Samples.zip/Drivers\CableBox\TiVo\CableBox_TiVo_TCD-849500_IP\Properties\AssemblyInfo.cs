// --------------------------------------------------------------------------------------------------------------------
// <copyright company="" file="AssemblyInfo.cs">
//   
// </copyright>
// 
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyTitle("CableBox_TiVo_TCD-849500_IP")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("CableBox_TiVo_TCD-849500_IP")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2016")]
[assembly: AssemblyVersion("20.0000.0023")]

