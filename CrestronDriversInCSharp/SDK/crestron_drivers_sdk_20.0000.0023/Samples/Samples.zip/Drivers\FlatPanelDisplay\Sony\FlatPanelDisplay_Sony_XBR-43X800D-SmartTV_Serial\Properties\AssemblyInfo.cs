using System.Reflection;

[assembly: AssemblyTitle("FlatPanelDisplay_Sony_XBR-43X800D_Serial")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("FlatPanelDisplay_Sony_XBR-43X800D_Serial")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyVersion("20.0000.0023")]

