﻿using Crestron.RAD.Common.Transports;

namespace SecuritySystem_Crestron_SampleDriverModel_Serial
{
    /// <summary>
    /// Sample transport class.
    /// </summary>
    public class SampleTransport : SimplTransport
    {
        public override void Start()
        {
            base.Start();

            var handler = DataHandler;
            if (DataHandler != null)
            {
                // Set system InitializationComplete.
                handler("InitializationComplete");
            }

            new SendTransportData(DataHandler);
        }
    }
}