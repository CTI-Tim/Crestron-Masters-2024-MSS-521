using System.Reflection;

[assembly: AssemblyTitle("Platform_Crestron_Sample_IP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Platform_Crestron_Sample_IP")]
[assembly: AssemblyCopyright("Copyright �  2020")]
[assembly: AssemblyVersion("20.0000.0023")]

