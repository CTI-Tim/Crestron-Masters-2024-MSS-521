using System.Reflection;

[assembly: AssemblyTitle("PairedExtensionDevice_Crestron_Sample")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("PairedExtensionDevice_Crestron_Sample")]
[assembly: AssemblyCopyright("Copyright �  2021")]
[assembly: AssemblyVersion("20.0000.0023")]

