﻿using System;
using System.Collections.Generic;
using Crestron.RAD.Common.Enums;
using Crestron.RAD.Common.Interfaces;
using Crestron.RAD.DeviceTypes.SecuritySystem;
using Crestron.SimplSharp;

namespace SecuritySystem_Crestron_SampleDriverModel_IP
{
    /// <summary>
    /// This class is used to define the security system keypad
    /// </summary>
    public class SecuritySystemKeypad : IEmulatedSecuritySystemKeypad, IDisposable
    {
        #region Fields

        protected SecuritySystemProtocol SecuritySystemProtocol;
        protected CTimer ArrowKeyRampTimer;
        protected ArrowDirections ArrowKeyRampingDirection;
        protected bool ArrowKeyIsRamping;
        private int _rampingTickRate = 500;

        #endregion

        #region Ctor

        /// <summary>
        /// Default constructor
        /// </summary>
        public SecuritySystemKeypad()
        {
            // Initialize few fake leds to have sample code 
            // We have many leds but for testing purpose we have added two
            // This leds are used to indicate the system state
            // Few system states are Arm/Disarm/Ready and so on
            Leds = new SecuritySystemKeypadLed[2];
            Leds[0] = new SecuritySystemKeypadLed(0) { State = new SecuritySystemKeypadIndicatorState(), Label = "Armed", Color = SecuritySystemKeypadLedColors.Red };
            Leds[1] = new SecuritySystemKeypadLed(1)
            {
                State = new SecuritySystemKeypadIndicatorState(),
                Label = "Ready",
                Color = SecuritySystemKeypadLedColors.Green
            };

            // We have fake function buttons for sample code
            // Using function button we have make system to stay/away/fire
            FunctionButtons = new SecuritySystemKeypadFunctionButton[3];
            FunctionButtons[0] = new SecuritySystemKeypadFunctionButton(0)
            {
                FunctionType = SecuritySystemKeypadFunctionType.Function,
                Icon = SecuritySystemKeypadFunctionButtonIcon.Stay,
                Label = new KeypadLabels() { PrimaryLabel = "Stay" }
            };
            FunctionButtons[1] = new SecuritySystemKeypadFunctionButton(1)
            {
                FunctionType = SecuritySystemKeypadFunctionType.Function,
                Icon = SecuritySystemKeypadFunctionButtonIcon.Away,
                Label = new KeypadLabels() { PrimaryLabel = "Away" }
            };
            FunctionButtons[2] = new SecuritySystemKeypadFunctionButton(2)
            {
                FunctionType = SecuritySystemKeypadFunctionType.Function,
                Icon = SecuritySystemKeypadFunctionButtonIcon.Fire,
                Label = new KeypadLabels() { PrimaryLabel = "Fire" },
            };
        }

        #endregion

        #region Property

        /// <summary>
        /// Keypad may need to be constructed before the protocol exists. This allows the flexibility.
        /// </summary>
        protected bool Initialized
        {
            get { return SecuritySystemProtocol != null; }
        }

        #endregion

        #region Events

        public event StateChangeHandler StateChange;

        #endregion

        #region Public/protected Method

        /// <summary>
        /// Initialize the security system protocol
        /// </summary>
        /// <param name="protocol">Sample Security System</param>
        public void Initialize(SecuritySystemProtocol protocol)
        {
            if (SecuritySystemProtocol != null)
            {
                SecuritySystemProtocol.StateChange -= SecuritySystemProtocolOnStateChange;
                SecuritySystemProtocol.AlarmChange -= SecuritySystemProtocolOnAlarmChange;
            }

            SecuritySystemProtocol = protocol;
            if (SecuritySystemProtocol != null)
            {
                SecuritySystemProtocol.StateChange += SecuritySystemProtocolOnStateChange;
                SecuritySystemProtocol.AlarmChange += SecuritySystemProtocolOnAlarmChange;
            }
        }

        /// <summary>
        /// Dipose the object
        /// </summary>
        public void Dispose()
        {
            //todo
            if (ArrowKeyRampTimer != null)
            {
                ArrowKeyRampTimer.Stop();
                ArrowKeyRampTimer.Dispose();
                ArrowKeyRampTimer = null;
                SecuritySystemProtocol.StateChange -= SecuritySystemProtocolOnStateChange;
                SecuritySystemProtocol.AlarmChange -= SecuritySystemProtocolOnAlarmChange;
            }
        }

        #endregion

        #region Numeric Keypad

        /// <summary>
        /// Property indicating that the KeypadNumber command is supported.
        /// </summary>
        public bool SupportsKeypadNumber { get { return true; } }

        /// <summary>
        /// Sends a keypad number to the device.
        /// </summary>
        /// <param name="number">Number to be sent to the device.</param>
        public void KeypadNumber(uint num)
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsKeypadNumber)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem, does not support KeypadNumber.");
                return;
            }

            SecuritySystemProtocol.SendKeypadNumber(num);
        }

        /// <summary>
        /// Property indicating that the Keypad Pound command is supported.
        /// </summary>
        public bool SupportsPound { get { return true; } }

        /// <summary>
        /// Method to send a Keypad "#" to the Device.
        /// </summary>
        public void Pound()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsPound)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem, does not support Keypad Pound.");
                return;
            }

            SecuritySystemProtocol.SendKeypadPound();
        }

        /// <summary>
        /// Property indicating that the Keypad Asterisk command is supported.
        /// </summary>
        public bool SupportsAsterisk
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send a Keypad "*" to the Device.
        /// </summary>
        public void Asterisk()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsAsterisk)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem, does not support Keypad Asterisk.");
                return;
            }

            SecuritySystemProtocol.SendKeypadAsterisk();
        }

        /// <summary>
        /// Property indicating that the Keypad Period command is supported.
        /// </summary>
        public bool SupportsPeriod { get { return true; } }

        /// <summary>
        /// Method to send a Keypad "." to the Device.
        /// </summary>
        public void Period()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsPeriod)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem, does not support Period.");
                return;
            }

            SecuritySystemProtocol.SendKeypadPeriod();
        }

        /// <summary>
        /// Property indicating that the Keypad Dash command is supported.
        /// </summary>
        public bool SupportsDash
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send a Keypad "-" to the Device.
        /// </summary>
        public void Dash()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsDash)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem, does not support Dash.");
                return;
            }

            SecuritySystemProtocol.SendKeypadDash();
        }

        /// <summary>
        /// Method to send a series of keypad characters to the device.
        /// </summary>
        /// <param name="keys"></param>
        public void SendKeypadString(string keys)
        {
            if (!Initialized)
            {
                return;
            }

            SecuritySystemProtocol.SendKeypadString(keys);
        }

        /// <summary>
        /// Property indicating that the Keypad Back Space command is supported.
        /// </summary>
        public bool SupportsKeypadBackSpace
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send a Back Space to the Device.
        /// </summary>
        public void KeypadBackSpace()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsKeypadBackSpace)
            {
                SecuritySystemProtocol.LogMessage("ASecuritySystem, does not support Keypad Back Space.");
                return;
            }

            SecuritySystemProtocol.SendKeypadBackSpace();
        }

        /// <summary>
        /// Property defining the "standard" labels for a numeric keypad buttons 0-9
        /// </summary>
        public KeypadLabels[] NumericKeypadLabels
        {
            get
            {
                return new[]
				{
					new KeypadLabels
					{
						PrimaryLabel = "0",
						SecondaryLabel = ""
					},
					new KeypadLabels
					{
						PrimaryLabel = "1",
						SecondaryLabel = "Arm" // This text will be displayed as secondary label on keypad button
					},
					new KeypadLabels
					{
						PrimaryLabel = "2",
						SecondaryLabel = "Disarm"
					},
					new KeypadLabels
					{
						PrimaryLabel = "3",
						SecondaryLabel = "User Attribute"
					},
					new KeypadLabels
					{
						PrimaryLabel = "4",
						SecondaryLabel = ""
					},
					new KeypadLabels
					{
						PrimaryLabel = "5",
						SecondaryLabel = ""
					},
					new KeypadLabels
					{
						PrimaryLabel = "6",
						SecondaryLabel = ""
					},
					new KeypadLabels
					{
						PrimaryLabel = "7",
						SecondaryLabel = ""
					},
					new KeypadLabels
					{
						PrimaryLabel = "8",
						SecondaryLabel = ""
					},
					new KeypadLabels
					{
						PrimaryLabel = "9",
						SecondaryLabel = ""
					}
				};
            }
        }

        /// <summary>
        /// Property defining the "standard" labels for a numeric keypad dash button
        /// </summary>
        public KeypadLabels DashLabels
        {
            get
            {
                return new KeypadLabels
                {
                    PrimaryLabel = "-",
                    SecondaryLabel = ""
                };
            }
        }

        /// <summary>
        /// Property defining the "standard" labels for a numeric keypad period button
        /// </summary>
        public KeypadLabels PeriodLabels
        {
            get
            {
                return new KeypadLabels
                {
                    PrimaryLabel = ".",
                    SecondaryLabel = ""
                };
            }
        }

        /// <summary>
        /// Property defining the "standard" labels for a numeric keypad asterisk button
        /// </summary>
        public KeypadLabels AsteriskLabels
        {
            get
            {
                return new KeypadLabels
                {
                    PrimaryLabel = "*",
                    SecondaryLabel = ""
                };
            }
        }

        /// <summary>
        /// Property defining the "standard" labels for a numeric keypad pound button
        /// </summary>
        public KeypadLabels PoundLabels
        {
            get
            {
                return new KeypadLabels
                {
                    PrimaryLabel = "#",
                    SecondaryLabel = ""
                };
            }
        }

        #endregion Keypad

        #region Navigation

        /// <summary>
        /// Property indicating that the ArrowKey command is supported.
        /// </summary>
        public bool SupportsArrowKeys
        {
            get { return true; }
        }

        /// <summary>
        /// Property indicating which Arrow Keys are supported.
        /// </summary>
        public List<ArrowDirections> ArrowKeysSupported
        {
            get { return new List<ArrowDirections>() { ArrowDirections.Down, ArrowDirections.Up, ArrowDirections.Right, ArrowDirections.Left }; }
        }

        public bool SupportsSelect { get; private set; }

        /// <summary>
        /// Method to send a arrow key to the Device.
        /// </summary>
        /// <param name="direction">Direction of arrow to be send to the device.</param>
        /// <param name="action">Indicates if command should be pressed, held, or released.</param>
        public void ArrowKey(ArrowDirections direction, CommandAction action)
        {
            if (!SupportsArrowKeys)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command ArrowKey is not supported");
                return;
            }

            switch (action)
            {
                case CommandAction.Hold:
                    PressArrowKey(direction);
                    break;
                case CommandAction.Release:
                    ReleaseArrowKey();
                    break;
                case CommandAction.None:
                    ArrowKey(direction);
                    break;
            }
        }

        /// <summary>
        /// Method to send an Arrow Key command to the Device.
        /// </summary>
        /// <param name="direction">Direction of the arrow key</param>
        public void ArrowKey(ArrowDirections direction)
        {
            if (!Initialized)
            {
                return;
            }

            SecuritySystemProtocol.SendKeypadArrowKeys(direction);
        }

        public void PressArrowKey(ArrowDirections direction)
        {
            if (ArrowKeyRampTimer == null)
            {
                ArrowKeyRampTimer = new CTimer(ArrowKeyTick, null, 0, _rampingTickRate);
            }

            ArrowKeyRampingDirection = direction;
            ArrowKeyIsRamping = true;
        }

        public void ReleaseArrowKey()
        {
            if (ArrowKeyRampTimer == null)
            {
                return;
            }

            ArrowKeyRampTimer.Stop();
            ArrowKeyRampTimer.Dispose();
            ArrowKeyRampTimer = null;

            ArrowKeyIsRamping = false;
        }

        protected void ArrowKeyTick(object obj)
        {
            if (ArrowKeyIsRamping)
            {
                ArrowKey(ArrowKeyRampingDirection);
            }
        }

        public void Select()
        {
            if (!SupportsSelect)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command Select is not supported");
                return;
            }
        }

        /// <summary>
        /// Property indicating that the Enter command is supported.
        /// </summary>
        public bool SupportsEnter
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send the enter command to the Device.
        /// </summary>
        public void Enter()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsEnter)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command Enter is not supported");
                return;
            }

            SecuritySystemProtocol.SendKeypadEnter();
        }

        /// <summary>
        /// Property indicating that the Clear command is supported.
        /// </summary>
        public bool SupportsClear
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send the clear command to the device.
        /// </summary>
        public void Clear()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsClear)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command Clear is not supported");
                return;
            }

            SecuritySystemProtocol.SendKeypadClear();
        }

        /// <summary>
        /// Property indicating that the Exit command is supported.
        /// </summary>
        public bool SupportsExit
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send the exit command to the Device.
        /// </summary>
        public void Exit()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsExit)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command Exit is not supported");
                return;
            }

            SecuritySystemProtocol.SendKeypadExit();
        }

        /// <summary>
        /// Property indicating that the Home command is supported.
        /// </summary>
        public bool SupportsHome
        {
            get { return true; }
        }

        /// <summary>
        /// Method to send the home command to the Device.
        /// </summary>
        public void Home()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsHome)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command Home is not supported");
                return;
            }

            SecuritySystemProtocol.SendKeypadHome();
        }

        /// <summary>
        /// Property indicating that the Menu command is supported.
        /// </summary>
        public bool SupportsMenu { get { return true; } }

        /// <summary>
        /// Method to send the menu command to the Device.
        /// </summary>
        public void Menu()
        {
            if (!Initialized)
            {
                return;
            }

            if (!SupportsMenu)
            {
                SecuritySystemProtocol.LogMessage("SecuritySystem : The command Menu is not supported");
                return;
            }

            SecuritySystemProtocol.SendKeypadMenu();
        }

        #endregion Navigation

        #region Keypad Status Text

        private string _statusText;

        /// <summary>
        /// Flag that indicates that Status Text Feedback is supported.
        /// </summary>
        public bool SupportsKeypadStatusText { get { return true; } }

        #endregion

        #region IEmulatedSecuritySystemKeypad Implementation

        /// <summary>
        /// Gets a list of security system keypad function buttons
        /// </summary>
        public SecuritySystemKeypadFunctionButton[] FunctionButtons { get; protected set; }


        /// <summary>
        /// Gets the list of security system keypad leds
        /// </summary>
        public SecuritySystemKeypadLed[] Leds { get; protected set; }

        /// <summary>
        /// Gets security system keypad status text
        /// </summary>
        public string StatusText
        {
            get { return _statusText; }
            set
            {
                _statusText = value;

                var textChangedEventArgs = new SecuritySystemKeypadTextChangedEventArgs()
                {
                    KeypadText = _statusText
                };

                var handler = SecuritysystemKeypadTextChanged;
                if (handler != null)
                    handler(this, textChangedEventArgs);
            }
        }

        /// <summary>
        /// Gets whether security system keypad supports function buttons or not
        /// </summary>
        public bool SupportsFunctionButtons
        {
            get { return true; }
        }

        /// <summary>
        /// Gets whether security system keypad supports leds or not
        /// </summary>
        public bool SupportsLeds { get { return true; } }

        /// <summary>
        /// Gets security system keypad supports textual display
        /// </summary>
        public bool SupportsTextualDisplay { get { return true; } }

        /// <summary>
        /// Event gets raised as a result of keypad text changed being issued to the security system
        /// <see cref=""/> 
        /// </summary>

        public event EventHandler<SecuritySystemKeypadTextChangedEventArgs> SecuritysystemKeypadTextChanged;

        /// <summary>
        /// Trigger the security system keypad function button
        /// </summary>
        /// <param name="functionButtonId"></param>
        public void TriggerFunctionButton(int buttonNumber)
        {
            if (!Initialized)
            {
                return;
            }

            SecuritySystemProtocol.TriggerFunctionButton(buttonNumber);
        }


        #endregion

        #region Private Method

        private void FireStateChangedEvent(SecuritySystemState eventType, bool state)
        {
            var stateObj = new SecuritySystemStateArgs
            {
                EventType = eventType,
                State = state
            };

            var handler = StateChange;
            if (handler != null)
            {
                handler(stateObj);
            }
        }

        /// <summary>
        /// Set the ready led on state.
        /// </summary>
        private void SetReadyLedOnState()
        {
            CrestronConsole.PrintLine("Set the ready led on state.");
            SecuritySystemKeypadIndicatorState indicatorState = new SecuritySystemKeypadIndicatorState();
            indicatorState.Index = 1;
            indicatorState.State = SecuritySystemKeypadIndicatorStateType.On;
            // Setting state will raise the led indicator changed event
            Leds[1].State = indicatorState;
            FireStateChangedEvent(SecuritySystemState.Ready, true);
        }

        private void SecuritySystemProtocolOnAlarmChange(object changedObject)
        {
            var obj = (SecuritySystemAlarmStateArgs)changedObject;
            if (obj != null && obj.State)
            {
                if (obj.Alarm.AlarmType == SecuritySystemAlarmType.Fire)
                    StatusText = ""; // keypad -  show empty text for fire alarm
            }
        }

        private void SecuritySystemProtocolOnStateChange(object changedObject)
        {
            var obj = (SecuritySystemStateArgs)changedObject;
            UpdateLedIndicator(0, obj.EventType);
            FireStateChangedEvent(obj.EventType, obj.State);

            StatusText = obj.EventType.ToString();
        }

        private void UpdateLedIndicator(int index, SecuritySystemState eventType)
        {
            SecuritySystemKeypadIndicatorStateType type = SecuritySystemKeypadIndicatorStateType.Unknown;

            switch (eventType)
            {
                case SecuritySystemState.ArmedStay:
                case SecuritySystemState.ArmedAway:
                    type = SecuritySystemKeypadIndicatorStateType.On;
                    break;
                case SecuritySystemState.Disarmed:
                    type = SecuritySystemKeypadIndicatorStateType.Off;
                    break;
            }

            if (type == SecuritySystemKeypadIndicatorStateType.Unknown)
            {
                CrestronConsole.PrintLine("Security system keypad : UpdateLedIndicator is called  index - {0}, event type - {1} ", index, eventType);
                return;
            }

            SecuritySystemKeypadLed led = new SecuritySystemKeypadLed(index);
            SecuritySystemKeypadIndicatorState indicatorState = new SecuritySystemKeypadIndicatorState();
            indicatorState.Index = index;
            indicatorState.State = type;
            led.State = indicatorState;
            ToggleLedState(led);
        }

        private void PrintSampleUserAttribute()
        {
            SecuritySystemProtocol.PrintAttributeValue();
        }

        /// <summary>
        /// Set led stae and trigger the events
        /// </summary>
        /// <param name="newLed"></param>
        private void ToggleLedState(ISecuritySystemKeypadLed newLed)
        {
            SecuritySystemProtocol.LogMessage("ToggleLedState method is callled for led index " + newLed.Index + "  Label : " + newLed.Label);
            if (Leds != null)
            {
                if (Leds[newLed.Index].State != newLed.State)
                {
                    Leds[newLed.Index].State = newLed.State;

                    // it's just for testing purpose
                    if (newLed.State.State == SecuritySystemKeypadIndicatorStateType.Off)
                    {
                        SetReadyLedOnState();
                    }
                    else
                    {
                        // When system is arm state then set the ready led to grey out
                        SecuritySystemKeypadIndicatorState indicatorState = new SecuritySystemKeypadIndicatorState();
                        indicatorState.Index = 1;
                        indicatorState.State = SecuritySystemKeypadIndicatorStateType.Off;
                        Leds[1].State = indicatorState;
                    }
                }
            }
        }

        #endregion
    }
}