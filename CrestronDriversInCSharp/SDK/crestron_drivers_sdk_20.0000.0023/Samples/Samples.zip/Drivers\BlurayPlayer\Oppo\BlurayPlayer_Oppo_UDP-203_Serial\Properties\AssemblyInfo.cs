using System.Reflection;

[assembly: AssemblyTitle("BlurayPlayer_Oppo_UDP-203_Serial")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("BlurayPlayer_Oppo_UDP-203_Serial")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2018")]
[assembly: AssemblyVersion("20.0000.0023")]

