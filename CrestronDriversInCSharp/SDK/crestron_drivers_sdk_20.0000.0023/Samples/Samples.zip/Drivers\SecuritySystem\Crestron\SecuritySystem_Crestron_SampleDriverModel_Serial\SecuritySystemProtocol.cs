﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Crestron.RAD.Common.BasicDriver;
using Crestron.RAD.Common.Enums;
using Crestron.RAD.Common.Events;
using Crestron.RAD.Common.Interfaces;
using Crestron.RAD.Common.Transports;
using Crestron.RAD.DeviceTypes.SecuritySystem;
using Crestron.SimplSharp;

namespace SecuritySystem_Crestron_SampleDriverModel_Serial
{
    public class SecuritySystemProtocol : ABaseDriverProtocol, IDisposable
    {
        #region Fields

        private string sampleAttributeValue = string.Empty;
        private ISecuritySystem _securitySystem;
        private List<ISecuritySystemZone> _zones { get; set; }
        private List<ISecuritySystemArea> _areas { get; set; }
        private bool _disposed = false;

        #endregion

        #region Property

        public ReadOnlyCollection<ISecuritySystemArea> Areas { get; private set; }
        public ReadOnlyCollection<ISecuritySystemZone> Zones { get; private set; }
        private Dictionary<StandardCommandsEnum, string> CommandsDictionary { get; set; }

        #endregion

        #region Ctor

        public SecuritySystemProtocol(ISecuritySystem system, ISerialTransport transportDriver, byte id)
            : base(transportDriver, id)
        {
            _securitySystem = system;
            InitializeCommands();
            InitializeCollections();

            CrestronConsole.PrintLine("SecuritySystemProtocol ctor is called");
        }

        #endregion

        #region Protected Memeber

        /// <summary>
        /// It's not needed for sample security system.
        /// </summary>
        /// <param name="validatedData"></param>
        protected override void ChooseDeconstructMethod(ValidatedRxData validatedData)
        {
        }

        protected override void ConnectionChangedEvent(bool connection)
        {
            var handler = ConnectedChanged;
            if (handler != null)
            {
                handler(this, new ValueEventArgs<bool>(connection));
            }
        }

        protected override void ConnectionChanged(bool connection)
        {
            CrestronConsole.PrintLine("Protocol : ConnectionChanged is called and IsConnected -{0} and connection - {1}", IsConnected, connection);
            if (connection == IsConnected) return;
            base.ConnectionChanged(connection);
        }

        #endregion

        #region Events

        public event StateChangeHandler StateChange;
        public event AlarmChangeHandler AlarmChange;
        public event ErrorChangeHandler ErrorChange;
        public event EventHandler<ValueEventArgs<bool>> ConnectedChanged;
        public event EventHandler<ListChangedEventArgs<ISecuritySystemZone>> ZoneListChanged;
        public event EventHandler<ListChangedEventArgs<ISecuritySystemArea>> AreaListChanged;
        public event EventHandler<SecuritySystemCommandResultEventArgs> SystemCommandResult;
        // this is for sample driver purpose, given option to change arm/disarm from keypad also
        public event StateChangeHandler KeypadChange;
        // this is for sample driver purpose, given option to change alarm from keypad also
        public event AlarmChangeHandler KeypadAlarmChange;

        #endregion

        #region Public Method

        /// <summary>
        /// Invoked by the transport class when it receives data from the controlled device.
        /// The default implementation of this is it adds the response to an instance of CrestronQueue
        /// that another thread monitors and eventually calls ValidateResponse with.
        /// </summary>
        /// <param name="rx">The data received from the device.</param>
        public override void DataHandler(string rx)
        {
            var data = ParseReceivedData(rx);
            CrestronConsole.PrintLine("SecuritySystemProtocol.DataHandler : data : " + data);
            switch (data)
            {
                case "createarea":
                    CreateFakeSecruritySystemArea();
                    break;
                case "createzone":
                    CreateFakeSecuritySystemZone();
                    break;
                case "disarm":
                    RaiseAreaStateChangedEvent(SecuritySystemState.Disarmed, true);
                    break;
                case "ready":
                    RaiseAreaStateChangedEvent(SecuritySystemState.Disarmed, false);
                    RaiseAreaStateChangedEvent(SecuritySystemState.Ready, true);
                    break;
                case "alarmon":
                    RaiseAlarmStateChangedEvent(SecuritySystemAlarmType.Alarm, true);
                    break;
                case "alarmoff":
                    RaiseAlarmStateChangedEvent(SecuritySystemAlarmType.Alarm, false);
                    break;
                case "error":
                    UpdateStateError(SecuritySystemError.NoAc, true);
                    break;
                case "InitializationComplete":
                    ConnectionChanged(true);
                    break;
                case "IsOffline":
                    ConnectionChanged(false);
                    break;
            }
        }

        /// <summary>
        /// When user sets the user attribute in crestron home, this method will be called
        /// We can use this value and write business logic
        /// </summary>
        /// <param name="attributeId"></param>
        /// <param name="attributeValue"></param>
        public override void SetUserAttribute(string attributeId, string attributeValue)
        {
            CrestronConsole.PrintLine("Set user attribute is called for  value  === > " + attributeValue);
            this.sampleAttributeValue = attributeValue;
        }

        public override void Dispose()
        {
            if (!_disposed)
            {
                if (_areas != null)
                {
                    foreach (var area in _areas)
                    {
                        var sArea = (area as SecuritySystemArea);
                        if (sArea == null) continue;

                        sArea.SecuritysystemAreaStateChangedEvent -= OnSecuritysystemAreaStateChangedEvent;
                        sArea.SecuritysystemAlarmStateChangedEvent -= OnSecuritysystemAlarmStateChangedEvent;
                        sArea.Dispose();
                    }

                    _areas.Clear();
                }

                if (_zones != null)
                {
                    _zones.Clear();
                }

                _disposed = true;
            }

            base.Dispose();
        }

        /// <summary>
        /// This is fake print - just to make sure the attribute is updated correctly
        /// </summary>
        public void PrintAttributeValue()
        {
            CrestronConsole.PrintLine("Sample attribute value  === > " + this.sampleAttributeValue);
        }

        public SecuritySystemOperationalResult ExecuteSecurityCommands(int commandIndex, List<int> areaIndexes, string password)
        {
            CrestronConsole.PrintLine("Protocol : ExecuteSecurityCommands is called for index - {0}, password - {1}  ", commandIndex, password);
            SecuritySystemOperationalResult commandResults;
            SecuritySystemAreaCommand executeCommand = null;
            foreach (var command in _securitySystem.GetAvailableAreaCommands())
            {
                CrestronConsole.PrintLine("Protocol : ExecuteSecurityCommands :  command index -{0}", command.Index);
                if (command.Index == commandIndex)
                {
                    executeCommand = command;
                }
            }
            if (executeCommand == null)
                commandResults = new SecuritySystemOperationalResult(1) { CommandType = executeCommand.CommandType, TargetComponentId = areaIndexes, Result = SecuritySystemOperationalResultCode.InvalidIdParameters };
            else
                switch (executeCommand.CommandType)
                {
                    case SecuritySystemCommandType.Away:
                    case SecuritySystemCommandType.Disarm:
                    case SecuritySystemCommandType.Stay:
                        commandResults = new SecuritySystemOperationalResult(1) { CommandType = executeCommand.CommandType, TargetComponentId = areaIndexes, Result = SecuritySystemOperationalResultCode.Success };
                        break;
                    default:
                        commandResults = new SecuritySystemOperationalResult(1) { CommandType = executeCommand.CommandType, TargetComponentId = areaIndexes, Result = SecuritySystemOperationalResultCode.InvalidIdParameters };
                        break;
                }

            if (executeCommand.CommandType == SecuritySystemCommandType.Disarm)
            {
                RaiseAlarmStateChangedEvent(SecuritySystemAlarmType.Fire, false);
                RaiseKeypadAlarmChangedEvent(SecuritySystemAlarmType.Fire, false);
            }

            var handler = SystemCommandResult;
            if (handler != null)
            {
                handler(this, new SecuritySystemCommandResultEventArgs() { CommandResult = commandResults });
            }

            return commandResults;
        }

        #endregion

        #region Logging

        internal void LogMessage(string message)
        {
            if (!EnableLogging) return;

            if (CustomLogger == null)
            {
                CrestronConsole.PrintLine(message);
            }
            else
            {
                CustomLogger(message + "\n");
            }
        }

        #endregion Logging

        #region Private Method

        private void UpdateStateError(SecuritySystemError errorType, bool updatedState)
        {
            var stateObj = new SecuritySystemErrorStateArgs
            {
                Error = errorType,
                State = updatedState
            };
            RaiseEventError(stateObj);
        }

        private void RaiseEventError(object obj)
        {
            var handler = ErrorChange;
            if (handler != null)
            {
                CrestronConsole.PrintLine(" Security system protocol: raised ErrorChange event");
                handler(obj);
            }
            else
            {
                CrestronConsole.PrintLine(" Security system protocol:  ErrorChange is null");
            }
        }

        private void CreateFakeSecruritySystemArea()
        {
            CrestronConsole.PrintLine("Security system protocol : CreateFakeSecruritySystemArea is called");

            var state = new List<SecuritySystemState>();
            state.Add(SecuritySystemState.ArmedAway);
            state.Add(SecuritySystemState.ArmedStay);
            state.Add(SecuritySystemState.Disarmed);

            var alramType = new List<SecuritySystemAlarmType>();
            alramType.Add(SecuritySystemAlarmType.Alarm);
            alramType.Add(SecuritySystemAlarmType.Fire);

            var areaCommand = new List<SecuritySystemAreaCommand>();
            areaCommand.Add(new SecuritySystemAreaCommand(1, SecuritySystemCommandType.Disarm, true));
            areaCommand.Add(new SecuritySystemAreaCommand(2, SecuritySystemCommandType.ForceAway, false));
            areaCommand.Add(new SecuritySystemAreaCommand(3, SecuritySystemCommandType.ForceStay, false));

            var securitySystemArea = new SecuritySystemArea("Area 1", 1, state.AsReadOnly(), alramType.AsReadOnly(), areaCommand.AsReadOnly(), this);

            securitySystemArea.SecuritysystemAreaStateChangedEvent += OnSecuritysystemAreaStateChangedEvent;
            securitySystemArea.SecuritysystemAlarmStateChangedEvent += OnSecuritysystemAlarmStateChangedEvent;

            _areas.Add(securitySystemArea);
            var handler = AreaListChanged;
            if (handler != null)
            {
                handler(this, new ListChangedEventArgs<ISecuritySystemArea>(ListChangedAction.Added, null, securitySystemArea, _areas.Count - 1));
                CrestronConsole.PrintLine("Security system protocol : CreateFakeSecruritySystemArea : Raised AreaListChanged event ");
            }
            else
            {
                CrestronConsole.PrintLine("Security system protocol : CreateFakeSecruritySystemArea : AreaListChanged is null ");
            }
        }

        private void CreateFakeSecuritySystemZone()
        {
            CrestronConsole.PrintLine("Security system protocol : CreateFakeSecuritySystemZone is called");
            var zone = new SecuritySystemZone("Zone1", 1, 1);
            _zones.Add(zone);
            var handler = ZoneListChanged;
            if (handler != null)
            {
                handler(this, new ListChangedEventArgs<ISecuritySystemZone>(ListChangedAction.Added, null, zone, _zones.Count - 1));
                CrestronConsole.PrintLine("Security system protocol : CreateFakeSecuritySystemZone : Raised ZoneListChanged event ");
            }
            else
            {
                CrestronConsole.PrintLine("Security system protocol : CreateFakeSecuritySystemZone : ZoneListChanged is null ");
            }
        }

        private void RaiseAreaStateChangedEvent(SecuritySystemState eventType, bool state)
        {
            CrestronConsole.PrintLine("Protocol : RaiseAreaStateChangedEvent is called.");
            var stateObj = new SecuritySystemStateArgs
            {
                EventType = eventType,
                State = state
            };

            var handler = StateChange;
            if (handler != null)
            {
                handler(stateObj);
                CrestronConsole.PrintLine("Protocol : RaiseAreaStateChangedEvent : Raised StateChange event .");
            }
            else
            {
                CrestronConsole.PrintLine("Protocol : RaiseAreaStateChangedEvent : StateChange event is null .");
            }
        }

        private void RaiseKeypadStateChangedEvent(SecuritySystemState eventType, bool state)
        {
            CrestronConsole.PrintLine("Protocol : RaiseKeypadStateChangedEvent is called.");
            var stateObj = new SecuritySystemStateArgs
            {
                EventType = eventType,
                State = state
            };

            var handler = KeypadChange;
            if (handler != null)
            {
                handler(stateObj);
                CrestronConsole.PrintLine("Protocol : RaiseKeypadStateChangedEvent : Raised KeypadChange event .");
            }
            else
            {
                CrestronConsole.PrintLine("Protocol : RaiseKeypadStateChangedEvent : KeypadChange event is null .");
            }
        }

        private void RaiseKeypadAlarmChangedEvent(SecuritySystemAlarmType eventType, bool state)
        {
            CrestronConsole.PrintLine("Protocol : RaiseKeypadAlarmChangedEvent is called.");
            var stateObj = new SecuritySystemAlarmStateArgs
            {
                Alarm = new SecuritySystemAlarm(eventType, state),
                State = state
            };

            var handler = KeypadAlarmChange;
            if (handler != null)
            {
                handler(stateObj);
                CrestronConsole.PrintLine("Protocol : RaiseKeypadAlarmChangedEvent : Raised KeypadAlarmChange event .");
            }
            else
            {
                CrestronConsole.PrintLine("Protocol : RaiseKeypadAlarmChangedEvent : KeypadAlarmChange event is null .");
            }
        }

        private void RaiseAlarmStateChangedEvent(SecuritySystemAlarmType eventType, bool state)
        {
            CrestronConsole.PrintLine("Protocol : RaiseAlarmStateChangedEvent is called.");
            var stateObj = new SecuritySystemAlarmStateArgs
            {
                Alarm = new SecuritySystemAlarm(eventType, state),
                State = state
            };

            var handler = AlarmChange;
            if (handler != null)
            {
                handler(stateObj);
                CrestronConsole.PrintLine("Protocol : RaiseAlarmStateChangedEvent : Raised AlarmChange event .");
            }
            else
            {
                CrestronConsole.PrintLine("Protocol : RaiseAlarmStateChangedEvent : AlarmChange event is null .");
            }
        }

        private void InitializeCollections()
        {
            CrestronConsole.PrintLine("Security system Protocol : InitializeCollections is called ");
            _areas = new List<ISecuritySystemArea>();
            _zones = new List<ISecuritySystemZone>();

            if (Zones == null)
                Zones = new ReadOnlyCollection<ISecuritySystemZone>(_zones);

            if (Areas == null)
                Areas = new ReadOnlyCollection<ISecuritySystemArea>(_areas);
        }

        private void InitializeCommands()
        {
            // Define all the commands required in security system
            // All the numberpad, action buttons, menu button and so on
            CommandsDictionary = new Dictionary<StandardCommandsEnum, string>()
            {
                {StandardCommandsEnum._0, "\x00"},
                {StandardCommandsEnum._1, "\x01"},
                {StandardCommandsEnum._2, "\x02"},
                {StandardCommandsEnum._3, "\x03"},
                {StandardCommandsEnum._4, "\x04"},
                {StandardCommandsEnum._5, "\x05"},
                {StandardCommandsEnum._6, "\x06"},
                {StandardCommandsEnum._7, "\x07"},
                {StandardCommandsEnum._8, "\x08"},
                {StandardCommandsEnum._9, "\x09"},
                {StandardCommandsEnum.Asterisk, "\x0A"},
                {StandardCommandsEnum.Period, "Period"},
                {StandardCommandsEnum.Dash, "Dash"},
                {StandardCommandsEnum.Octothorpe, "\x0B"},
                {StandardCommandsEnum.FunctionButton1, "\x1C"},
                {StandardCommandsEnum.FunctionButton2, "\x1D"},
                {StandardCommandsEnum.FunctionButton3, "\x1E"},
                {StandardCommandsEnum.FunctionButton4, "\x1F"},
                {StandardCommandsEnum.Menu, "Menu"},
                {StandardCommandsEnum.Home, "Home"},
                {StandardCommandsEnum.Exit, "Exit"},
                {StandardCommandsEnum.Clear, "Clear"},
                {StandardCommandsEnum.RightArrow, "RightArrow"},
                {StandardCommandsEnum.LeftArrow, "LeftArrow"},
                {StandardCommandsEnum.DownArrow, "DownArrow"},
                {StandardCommandsEnum.UpArrow, "UpArrow"},
                {StandardCommandsEnum.KeypadBackSpace, "KeypadBackSpace"},
                { StandardCommandsEnum.SetSystemStateToArmStay,"SetSystemStateToArmStay"},
                { StandardCommandsEnum.SetSystemStateToDisarmed,"SetSystemStateToDisarmed"},
                { StandardCommandsEnum.SetSystemStateToArmInstant,"SetSystemStateToArmInstant"},
            };
        }

        /// <summary>
        /// This method is used to parse the input data
        /// </summary>
        /// <param name="rx"></param>
        /// <returns></returns>
        private string ParseReceivedData(string rx)
        {
            // Use the paring logic.
            return rx;
        }

        private void OnSecuritysystemAreaStateChangedEvent(object sender, ListChangedEventArgs<SecuritySystemState> args)
        {
            var updatedState = false;
            if (args != null)
            {
                var state = SecuritySystemState.Unknown;
                switch (args.ChangedAction)
                {
                    case ListChangedAction.Added:
                        state = args.NewItem;
                        updatedState = true;
                        break;
                    case ListChangedAction.Removed:
                        state = args.OldItem;
                        break;
                }

                RaiseAreaStateChangedEvent(state, updatedState);
            }
        }

        private void OnSecuritysystemAlarmStateChangedEvent(object sender, ListChangedEventArgs<SecuritySystemAlarmType> args)
        {
            if (args != null)
            {
                var type = SecuritySystemAlarmType.Unknown;
                var state = false;
                switch (args.ChangedAction)
                {
                    case ListChangedAction.Added:
                        type = args.NewItem;
                        state = true;
                        break;
                    case ListChangedAction.Removed:
                        type = args.OldItem;
                        break;
                }

                RaiseAlarmStateChangedEvent(type, state);
            }
        }

        #endregion

        #region Keypad Operation

        /// <summary>
        /// Sends a keypad number to the device.
        /// </summary>
        /// <param name="number">Number to be sent to the device.</param>
        public void SendKeypadNumber(uint num)
        {
            if (num == 0 && CommandsDictionary.ContainsKey(StandardCommandsEnum._0))
            {
                var commandSet = new CommandSet("0", "0", CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum._0);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("KeypadNumber method is called for number " + num);

            while (num > 0)
            {
                var digit = num % 10;
                StandardCommandsEnum numberEnum;
                switch (digit)
                {
                    case 0:
                        numberEnum = StandardCommandsEnum._0;
                        break;
                    case 1:
                        numberEnum = StandardCommandsEnum._1;
                        // Raise event is used to show sample code to work properly
                        // should not be used in real driver
                        RaiseAreaStateChangedEvent(SecuritySystemState.ArmedStay, true);
                        RaiseKeypadStateChangedEvent(SecuritySystemState.ArmedStay, true);
                        break;
                    case 2:
                        numberEnum = StandardCommandsEnum._2;
                        // Raise event is used to show sample code to work properly
                        // should not be used in real driver
                        RaiseAreaStateChangedEvent(SecuritySystemState.Disarmed, true);
                        RaiseKeypadStateChangedEvent(SecuritySystemState.Disarmed, true);
                        break;
                    case 3:
                        numberEnum = StandardCommandsEnum._3;
                        PrintAttributeValue();
                        break;
                    case 4:
                        numberEnum = StandardCommandsEnum._4;
                        break;
                    case 5:
                        numberEnum = StandardCommandsEnum._5;
                        break;
                    case 6:
                        numberEnum = StandardCommandsEnum._6;
                        break;
                    case 7:
                        numberEnum = StandardCommandsEnum._7;
                        break;
                    case 8:
                        numberEnum = StandardCommandsEnum._8;
                        break;
                    case 9:
                        numberEnum = StandardCommandsEnum._9;
                        break;
                    default:
                        return;
                }

                if (!CommandsDictionary.ContainsKey(numberEnum)) return;

                var commandSet = new CommandSet(numberEnum.ToString(), numberEnum.ToString(), CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, numberEnum);
                PrepareStringThenSend(commandSet);
                num = num / 10;
            }
        }

        /// <summary>
        /// Method to send a Keypad "#" to the Device.
        /// </summary>
        public void SendKeypadPound()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Octothorpe))
            {
                var commandSet = new CommandSet("KeypadPound", StandardCommandsEnum.Octothorpe.ToString(), CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.KeypadPound);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Pound method is called");
        }

        /// <summary>
        /// Method to send a Keypad "*" to the Device.
        /// </summary>
        public void SendKeypadAsterisk()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Asterisk))
            {
                var commandSet = new CommandSet("KeypadAsterisk", StandardCommandsEnum.Asterisk.ToString(), CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Asterisk);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Asterisk method is called");
        }

        /// <summary>
        /// Method to send a Keypad "." to the Device.
        /// </summary>
        public void SendKeypadPeriod()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Period))
            {
                var commandSet = new CommandSet("Period", StandardCommandsEnum.Period.ToString(), CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Period);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Period method is called");
        }

        /// <summary>
        /// Method to send a Keypad "-" to the Device.
        /// </summary>
        public void SendKeypadDash()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Dash))
            {
                var commandSet = new CommandSet("Dash", StandardCommandsEnum.Dash.ToString(), CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Dash);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Dash method is called");
        }

        /// <summary>
        /// Method to send a series of keypad characters to the device.
        /// </summary>
        /// <param name="keys"></param>
        public void SendKeypadString(string keys)
        {
            if (keys.Length >= 20)
                keys = keys.Substring(0, 20);

            foreach (var key in keys)
            {
                var commandName = string.Empty;
                StandardCommandsEnum commandEnums = StandardCommandsEnum._0;

                switch (key)
                {
                    case '0':
                        commandName = "0";
                        break;
                    case '1':
                        commandEnums = StandardCommandsEnum._1;
                        commandName = "1";
                        break;
                    case '2':
                        commandEnums = StandardCommandsEnum._2;
                        commandName = "2";
                        break;
                    case '3':
                        commandEnums = StandardCommandsEnum._3;
                        commandName = "3";
                        break;
                    case '4':
                        commandEnums = StandardCommandsEnum._4;
                        commandName = "4";
                        break;
                    case '5':
                        commandEnums = StandardCommandsEnum._5;
                        commandName = "5";
                        break;
                    case '6':
                        commandEnums = StandardCommandsEnum._6;
                        commandName = "6";
                        break;
                    case '7':
                        commandEnums = StandardCommandsEnum._7;
                        commandName = "7";
                        break;
                    case '8':
                        commandEnums = StandardCommandsEnum._8;
                        commandName = "8";
                        break;
                    case '9':
                        commandEnums = StandardCommandsEnum._9;
                        commandName = "9";
                        break;
                    case '.':
                        commandEnums = StandardCommandsEnum.Period;
                        commandName = ".";
                        break;
                    case '-':
                        commandEnums = StandardCommandsEnum.Dash;
                        commandName = "-";
                        break;
                    case '*':
                        commandEnums = StandardCommandsEnum.Asterisk;
                        commandName = "*";
                        break;
                    case '#':
                        commandEnums = StandardCommandsEnum.Octothorpe;
                        commandName = "#";
                        break;
                    default:
                        continue;
                }

                var commandSet = new CommandSet(commandName, commandEnums.ToString(),
                    CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, commandEnums);
                PrepareStringThenSend(commandSet);

                LogMessage("SendKeypadString method is called for commandName : " + commandName + ", enum : " + commandEnums);
            }
        }

        /// <summary>
        /// Method to send a Back Space to the Device.
        /// </summary>
        public void SendKeypadBackSpace()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.KeypadBackSpace))
            {
                var commandSet = new CommandSet("KeypadBackSpace", StandardCommandsEnum.KeypadBackSpace.ToString(), CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.KeypadBackSpace);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("KeypadBackSpace method is called ");
        }

        /// <summary>
        /// Method to send an Arrow Key command to the Device.
        /// </summary>
        /// <param name="direction">Direction of the arrow key</param>
        public void SendKeypadArrowKeys(ArrowDirections direction)
        {
            StandardCommandsEnum numberEnum;
            switch (direction)
            {
                case ArrowDirections.Up:
                    numberEnum = StandardCommandsEnum.UpArrow;
                    break;
                case ArrowDirections.Down:
                    numberEnum = StandardCommandsEnum.DownArrow;
                    break;
                case ArrowDirections.Left:
                    numberEnum = StandardCommandsEnum.LeftArrow;
                    break;
                case ArrowDirections.Right:
                    numberEnum = StandardCommandsEnum.RightArrow;
                    break;
                default:
                    return;
            }

            if (!CommandsDictionary.ContainsKey(numberEnum)) return;

            var commandSet = new CommandSet(numberEnum.ToString(), numberEnum.ToString(),
                  CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, numberEnum);
            PrepareStringThenSend(commandSet);

            LogMessage("ArrowKey method is called for direction  " + numberEnum);
        }

        /// <summary>
        /// Method to send the enter command to the Device.
        /// </summary>
        public void SendKeypadEnter()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Enter))
            {
                var commandSet = new CommandSet("Enter", "Enter",
                CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Enter);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Enter method is called");
        }

        /// <summary>
        /// Method to send the clear command to the device.
        /// </summary>
        public void SendKeypadClear()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Clear))
            {
                var commandSet = new CommandSet("Clear", "Clear",
                              CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Clear);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Clear method is called");
        }

        /// <summary>
        /// Method to send the exit command to the Device.
        /// </summary>
        public void SendKeypadExit()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Exit))
            {
                var commandSet = new CommandSet("Exit", "Exit",
                                CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Exit);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Exit method is called");
        }

        /// <summary>
        /// Method to send the home command to the Device.
        /// </summary>
        public void SendKeypadHome()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Home))
            {
                var commandSet = new CommandSet("Home", "Home",
                             CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Home);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Home method is called");
        }

        /// <summary>
        /// Method to send the menu command to the Device.
        /// </summary>
        public void SendKeypadMenu()
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.Menu))
            {
                var commandSet = new CommandSet("Menu", "Menu",
                               CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, StandardCommandsEnum.Menu);
                PrepareStringThenSend(commandSet);
            }

            LogMessage("Menu method is called");
        }

        /// Trigger the security system keypad function button
        /// </summary>
        /// <param name="functionButtonId"></param>
        public void TriggerFunctionButton(int buttonNumber)
        {
            if (CommandsDictionary.ContainsKey(StandardCommandsEnum.FunctionButton1))
            {
                StandardCommandsEnum commandEnum = StandardCommandsEnum.FunctionButton1;
                switch (buttonNumber)
                {
                    case 1:
                        commandEnum = StandardCommandsEnum.FunctionButton1;
                        // action button stay
                        RaiseAreaStateChangedEvent(SecuritySystemState.ArmedStay, true);
                        RaiseKeypadStateChangedEvent(SecuritySystemState.ArmedStay, true);
                        break;
                    case 2:
                        commandEnum = StandardCommandsEnum.FunctionButton2;
                        // action button away
                        RaiseAreaStateChangedEvent(SecuritySystemState.ArmedAway, true);
                        RaiseKeypadStateChangedEvent(SecuritySystemState.ArmedAway, true);
                        break;
                    case 3:
                        commandEnum = StandardCommandsEnum.FunctionButton3;
                        // action button fire.
                        RaiseAlarmStateChangedEvent(SecuritySystemAlarmType.Fire, false);
                        RaiseAlarmStateChangedEvent(SecuritySystemAlarmType.Fire, true);

                        RaiseKeypadAlarmChangedEvent(SecuritySystemAlarmType.Fire, false);
                        RaiseKeypadAlarmChangedEvent(SecuritySystemAlarmType.Fire, true);

                        break;
                    case 4:
                        commandEnum = StandardCommandsEnum.FunctionButton4;
                        break;
                    case 5:
                        commandEnum = StandardCommandsEnum.FunctionButton5;
                        break;
                    case 6:
                        commandEnum = StandardCommandsEnum.FunctionButton6;
                        break;
                    case 7:
                        commandEnum = StandardCommandsEnum.FunctionButton7;
                        break;
                    case 8:
                        commandEnum = StandardCommandsEnum.FunctionButton8;
                        break;
                    default:
                        return;
                }

                var commandSet = new CommandSet(commandEnum.ToString(), commandEnum.ToString(),
                           CommonCommandGroupType.Unknown, null, false, CommandPriority.Low, commandEnum);
                PrepareStringThenSend(commandSet);

                LogMessage("TriggerFunctionButton method is called for  " + commandEnum);
            }
        }

        #endregion
    }

    public delegate void StateChangeHandler(object changedObject);
    public delegate void AlarmChangeHandler(object changedObject);
    public delegate void ErrorChangeHandler(object changedObject);

    /// <summary>
    /// This class is used to define the event args for built in security system state.
    /// </summary>
    internal class SecuritySystemStateArgs
    {
        /// <summary>
        /// Get/Set Security system event type
        /// </summary>
        public SecuritySystemState EventType { get; set; }

        /// <summary>
        /// Get/Set Security system state.
        /// </summary>
        public bool State { get; set; }
    }

    /// <summary>
    /// This class is used to define the event args for security system error state
    /// </summary>
    internal class SecuritySystemErrorStateArgs
    {
        /// <summary>
        /// Get/Set the security system error type
        /// </summary>
        public SecuritySystemError Error { get; set; }

        /// <summary>
        /// Get/Set the security system error state
        /// </summary>
        public bool State { get; set; }
    }

    /// <summary>
    /// This class is used to define the event args for security system alarm state
    /// </summary>
    internal class SecuritySystemAlarmStateArgs
    {
        /// <summary>
        /// Get/Set the security system alarm type
        /// </summary>
        public SecuritySystemAlarm Alarm { get; set; }

        /// <summary>
        /// Get/Set the security system  state
        /// </summary>
        public bool State { get; set; }
    }
}