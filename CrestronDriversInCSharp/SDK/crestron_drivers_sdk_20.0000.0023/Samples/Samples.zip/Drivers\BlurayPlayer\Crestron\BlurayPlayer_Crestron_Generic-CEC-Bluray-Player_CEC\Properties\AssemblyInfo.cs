// --------------------------------------------------------------------------------------------------------------------
// <copyright company="" file="AssemblyInfo.cs">
//   
// </copyright>
// 
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyTitle("BlurayPlayer_Crestron_Generic-CEC-Bluray-Player_CEC")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("BlurayPlayer_Crestron_Generic-CEC-Bluray-Player_CEC")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2016")]
[assembly: AssemblyVersion("20.0000.0023")]

