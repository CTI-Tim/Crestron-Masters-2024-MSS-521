﻿using Crestron.RAD.Common.Transports;
using Crestron.SimplSharp;

namespace SecuritySystem_Crestron_SampleDriverModel_IP
{
    /// <summary>
    /// Sample transport class.
    /// </summary>
    public class SampleTransport : TcpTransport
    {
        public override void Start()
        {
            CrestronConsole.PrintLine("SampleTransport Start method is called");

            base.Start();

            var handler = DataHandler;
            if (DataHandler != null)
            {
                // Set system InitializationComplete.
                handler("InitializationComplete");
            }

            new SendTransportData(DataHandler);
        }
    }
}