using System.Reflection;

[assembly: AssemblyTitle("CecBlurayPlayer")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("CecBlurayPlayer")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2017")]
[assembly: AssemblyVersion("20.0000.0023")]

