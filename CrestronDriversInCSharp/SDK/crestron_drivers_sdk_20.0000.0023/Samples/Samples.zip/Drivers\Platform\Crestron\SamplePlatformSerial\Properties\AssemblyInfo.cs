using System.Reflection;

[assembly: AssemblyTitle("Platform_Crestron_Sample_Serial")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Platform_Crestron_Sample_Serial")]
[assembly: AssemblyCopyright("Copyright �  2021")]
[assembly: AssemblyVersion("20.0000.0023")]

