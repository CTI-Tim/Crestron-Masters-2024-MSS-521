using System.Reflection;

[assembly: AssemblyTitle("FlatPanelDisplay_Sony_XBR_43X800D_Tcp")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("FlatPanelDisplay_Sony_XBR_43X800D_Tcp")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyVersion("20.0000.0023")]

