// --------------------------------------------------------------------------------------------------------------------
// <copyright company="" file="AssemblyInfo.cs">
//   
// </copyright>
// 
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyTitle("CableBox_Contemporary-Research_232-ATSC-4_Serial")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("CableBox_Contemporary-Research_232-ATSC-4_Serial")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2016")]
[assembly: AssemblyVersion("20.0000.0023")]

